//
//  EditingAllocationView.m
//  Make-ROV : Multi Motor Allocation
//
//  Created by testing on 17/2/2015.
//  Copyright (c) 2015年 pcms.rovTeam. All rights reserved.
//

#import "EditingAllocationView.h"
#import "ViewController.h"

@interface EditingAllocationView ()

@end

@implementation EditingAllocationView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
	NSLog(@"clicked1");
}




@end
