//
//  ViewController.h
//  Make-ROV : Multi Motor Allocation
//
//  Created by testing on 17/2/2015.
//  Copyright (c) 2015年 pcms.rovTeam. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController{
	IBOutlet NSButton *_createNewBtn;
	IBOutlet NSWindow *_mainWindow;
}


@end

