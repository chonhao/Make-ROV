//
//  ViewController.m
//  Make-ROV : Multi Motor Allocation
//
//  Created by testing on 17/2/2015.
//  Copyright (c) 2015年 pcms.rovTeam. All rights reserved.
//

#import "ViewController.h"
#import "EditingAllocationView.h"

@implementation ViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
	[super setRepresentedObject:representedObject];

	// Update the view, if already loaded.
}

- (IBAction)createNew:(id)sender {
	NSLog(@"clicked");
	
}


@end
