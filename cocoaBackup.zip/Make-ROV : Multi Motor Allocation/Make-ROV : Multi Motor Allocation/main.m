//
//  main.m
//  Make-ROV : Multi Motor Allocation
//
//  Created by testing on 17/2/2015.
//  Copyright (c) 2015年 pcms.rovTeam. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
