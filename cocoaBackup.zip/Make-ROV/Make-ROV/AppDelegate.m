//
//  AppDelegate.m
//  Make-ROV
//
//  Created by testing on 16/2/2015.
//  Copyright (c) 2015年 pcms.ROVteam. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}

@end
