//
//  welcomeImageClass.m
//  Make-ROV
//
//  Created by testing on 16/2/2015.
//  Copyright (c) 2015年 pcms.ROVteam. All rights reserved.
//

#import "welcomeImageClass.h"

@implementation welcomeImageClass

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
